
package controlador;


public class RegistroHotel {
    
}
