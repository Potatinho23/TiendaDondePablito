
package modelo;

public class Hotel {
    
}
